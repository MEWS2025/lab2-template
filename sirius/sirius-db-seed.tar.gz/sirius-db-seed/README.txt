# sirius-db-seed-20251028_150552

Portable snapshot of Postgres 17 from container "sirius-web-postgres".

## Quick start
run_with_seed.cmd

Port: 5433
JDBC: jdbc:postgresql://localhost:5433/sirius-web-db
User: dbuser   Password: dbpwd
