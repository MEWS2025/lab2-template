# sirius-db-seed-2025-10-26_05-34-34

This archive contains a snapshot of Postgres 17 data from container `sirius-web-postgres`.

## Quick start
```bash
./run_with_seed.sh
```

Postgres will listen on port 5433.
JDBC: `jdbc:postgresql://localhost:5433/sirius-web-db`
User: `dbuser`  Password: `dbpwd`
